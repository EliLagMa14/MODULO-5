package com.rsr.curso.estudiante.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rsr.curso.estudiante.entity.Estudiante;
import com.rsr.curso.estudiante.repository.EstudianteDAO;

import jakarta.transaction.Transactional;

@Service
public class EstudianteService implements EstudianteServ {

	@Autowired
	private EstudianteDAO estudianteDao;
	
	@Transactional
	public List<Estudiante> findAll(){
		return (List <Estudiante>) estudianteDao.findAll();
	}
	
	@Transactional
	public Estudiante save(Estudiante estudiante){
		
		return estudianteDao.save(estudiante);
	}
	
	//busqueda por id
	public Estudiante findById(Long id) {
		return estudianteDao.findById(id).orElse(null);
	}
	
	@Transactional
	public void delete(Estudiante estudiante){
		
	  estudianteDao.delete(estudiante);
	}
	@Override
    @Transactional
    public Estudiante update(Estudiante estudiante, Long id) {
        Estudiante existingEstudiante = estudianteDao.findById(id).orElse(null);
        if (existingEstudiante != null) {
            existingEstudiante.setNombre(estudiante.getNombre());
            existingEstudiante.setDireccion(estudiante.getDireccion());
            existingEstudiante.setTelefono(estudiante.getTelefono());
            return estudianteDao.save(existingEstudiante);
        } else {
            throw new IllegalArgumentException("Estudiante no encontrado con ID: " + id);
        }
    }
	
}
